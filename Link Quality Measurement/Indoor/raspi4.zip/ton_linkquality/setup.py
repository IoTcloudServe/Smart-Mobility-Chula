
Pi1 ='10.0.0.1'
Pi2 ='10.0.0.2'
Pi3 ='10.0.0.3'
Pi4 ='10.0.0.4'
Pi5 ='10.0.0.5'
Pi6 ='10.0.0.6'
GW1 ='10.0.0.8'
GW2 ='10.0.0.9'

R1=[Pi1,GW1]
R2=[Pi4,GW1]

N = 20
S1=[R1]
S2=[R2]
S3=[R1]
S4=[R2]
S5=[R1]
S6=[R2]
S7=[R1]
S8=[R2]
S9=[R1]
S10=[R2]
S11=[R1]
S12=[R2]
S13=[R1]
S14=[R2]
S15=[R1]
S16=[R2]
S17=[R1]
S18=[R2]
S19=[R1]
S20=[R2]
S=[S1,S2,S3,S4,S5,S6,S7,S8,S9,S10,S11,S12,S13,S14,S15,S16,S17,S18,S19,S20]

name1=["R1"]
name2=["R2"]
Name=[name1,name2,name1,name2,name1,name2,name1,name2,name1,name2,name1,name2,name1,name2,name1,name2,name1,name2,name1,name2]


Pi1 ='10.0.0.1'
Pi2 ='10.0.0.2'
Pi3 ='10.0.0.3'
Pi4 ='10.0.0.4'
Pi5 ='10.0.0.5'
Pi6 ='10.0.0.6'
GW1 ='10.0.0.8'
GW2 ='10.0.0.9'

R1=[GW1,Pi1]
R2=[GW1,Pi4]
R3=[Pi1,Pi4]
R4=[Pi1,Pi2]
R5=[Pi4,Pi5]
R6=[Pi2,Pi5]
R7=[Pi3,Pi2]
R8=[Pi6,Pi5]
R9=[Pi3,Pi6]
R10=[GW2,Pi3]
R11=[GW2,Pi6]

N = 4
S1=[R4,R5]
S2=[R7,R8]
S3=[R3,R6]
S4=[R6,R9]
S=[S1,S2,S3,S4]

name1=["R4","R5"]
name2=["R7","R8"]
name3=["R3","R6"]
name4=["R6","R9"]
Name=[name1,name2,name3,name4]
